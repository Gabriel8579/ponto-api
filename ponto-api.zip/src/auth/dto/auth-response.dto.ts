export class AuthResponseDto {
   token: string
}