import { Body, Controller, Get, HttpCode, Param, ParseIntPipe, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { GetUser } from 'src/auth/get-user.decorator';
import { Roles } from 'src/auth/roles.decorator';
import { RolesGuard } from 'src/auth/roles.guard';
import CreateUserDto from './dto/create-user.dto';
import User from './entities/user.entity';
import { Role } from './enums/roles.enum';
import { UsersService } from './users.service';

@Controller('users')
@UseGuards(AuthGuard(), RolesGuard)
export class UsersController {
   
   constructor(
      private usersService: UsersService,
   ) {}

   @Post()
   @Roles(Role.APPLICATION_ADMIN, Role.COMPANY_ADMIN)
   createUser(@Body() createUserDto: CreateUserDto, @GetUser() issuer: User) {
      return this.usersService.createUser(createUserDto, issuer);
   }

   @Get()
   @Roles(Role.APPLICATION_ADMIN, Role.COMPANY_ADMIN)
   async listUsers(@GetUser() issuer, @Query('companyId') companyId?: number): Promise<User[]> {
      return await this.usersService.listUsers(issuer, companyId);
   }

   @Patch(":userId/activate") 
   @Roles(Role.APPLICATION_ADMIN, Role.COMPANY_ADMIN)
   @HttpCode(200)
   activateUser(@Param('userId', ParseIntPipe) userId: number, @GetUser() issuer: User) {
      return this.usersService.activateUser(userId, issuer);
   }

   @Patch(":userId/deactivate") 
   @Roles(Role.APPLICATION_ADMIN, Role.COMPANY_ADMIN)
   @HttpCode(200)
   deactivateUser(@Param('userId', ParseIntPipe) userId: number, @GetUser() issuer: User) {
      return this.usersService.deactivateUser(userId, issuer);
   }

   @Patch(':userId/role')
   @Roles(Role.APPLICATION_ADMIN, Role.COMPANY_ADMIN)
   @HttpCode(200)
   setUserRole(@Param('userId', ParseIntPipe) userId: number, @GetUser() issuer: User) {
      return this.setUserRole(userId, issuer);
   }

}
